

import java.sql.*;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;



public class AddPatient1 {
    
   public void insertUpdateDeletePatient(char operation, Integer id, String fname, String lname, String sex, String age, String sisiId, String profession,
                                        String branch, String phone, String address, String register, String allergyinfo, String email, String emd,
                                        String job, String education)
   {
       Connection con = MyConnection.getConnection();
       
       
       
       
       if(operation == 'i')
       {
           String sql = "INSERT INTO patient(FirstName, LastName, Sex, Age, SisiID, Profession, Branch, Phone, Address, Register, Allergyinfo, Email, EMD, Job, Education) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
           try {
               PreparedStatement ps = con.prepareStatement(sql);
               ps.setString(1, fname);
               ps.setString(2, lname);
               ps.setString(3, sex);
               ps.setString(4, age);
               ps.setString(5, sisiId);
               ps.setString(6, profession);
               ps.setString(7, branch);
               ps.setString(8, phone);
               ps.setString(9, address);
               ps.setString(10, register);
               ps.setString(11, allergyinfo);
               ps.setString(12, email);
               ps.setString(13, emd);
               ps.setString(14, job);
               ps.setString(15, education);
               
               if(ps.executeUpdate() > 0){
                            JOptionPane.showMessageDialog(null, "New Patient added");
                           
                            
               }
                       
           } catch (SQLException ex) {
               Logger.getLogger(AddPatient1.class.getName()).log(Level.SEVERE, null, ex);
           }
           
       }
   }        

    public void fillStudentTable(JTable table, String ValueToSearch)
    {
         Connection con = MyConnection.getConnection();
         String sql = "SELECT * FROM patient WHERE CONCAT(FirstName, LastName, Age, SisiID, Profession, Branch, Phone, Address, Register, Allergyinfo, Email, EMD, Job, Education) LIKE ?";
         
       try {
           PreparedStatement ps = con.prepareStatement(sql);
           ps.setString(1, "%"+ValueToSearch+"%");
           ResultSet rs = ps.executeQuery();
           
           DefaultTableModel model = (DefaultTableModel) table.getModel();
           Object[] row;
           
           while(rs.next()){
               row = new Object[16];
               row[0] = rs.getInt(1);
               row[1] = rs.getString(2);
               row[2] = rs.getString(3);
               row[3] = rs.getString(4);
               row[4] = rs.getString(5);
               row[5] = rs.getString(6);
               row[6] = rs.getString(7);
               row[7] = rs.getString(8);
               row[8] = rs.getString(9);
               row[9] = rs.getString(10);
               row[10] = rs.getString(11);
               row[11] = rs.getString(12);
               row[12] = rs.getString(13);
               row[13] = rs.getString(14);
               row[14] = rs.getString(15);
               row[15] = rs.getString(16);
               
               model.addRow(row);
           }
       } catch (SQLException ex) {
           Logger.getLogger(AddPatient1.class.getName()).log(Level.SEVERE, null, ex);
       }
    }
   
    
           

    

    
}
